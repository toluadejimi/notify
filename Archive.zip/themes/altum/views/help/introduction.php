<?php defined('ALTUMCODE') || die() ?>

<h1 class="h4"><?= l('help.introduction.header') ?></h1>

<p class=""><?= sprintf(l('help.introduction.p1'), '<a href="' . url() .'">' . settings()->main->title . '</a>') ?></p>

<p class=""><?= l('help.introduction.p2') ?></p>

<p class=""><?= l('help.introduction.p3') ?></p>

